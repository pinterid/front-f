// The structure what the user gets
var platformObj = require("./../Structure/platform.json");
var orgObj = require("./../Structure/organization.json");
var yearObj = require("./../Structure/year.json");
var dayObj = require("./../Structure/day.json");
var contribObj = require("./../Structure/contribution.json");
var memberObj = require("./../Structure/member.json");

// Works what the structure assembles
export function getTranslatorObj(objUser) {
  console.log(objUser);

  /** platform.(?) */
  platformObj.platformName = "GitHub";
  platformObj.platformUrl = "https://github.com";
  platformObj.avatarUrl = objUser.profile.avatarUrl;
  platformObj.websiteUrl = objUser.profile.websiteUrl;
  platformObj.company = objUser.profile.company;
  platformObj.email = objUser.profile.email;
  platformObj.name = objUser.profile.name;
  platformObj.createdAt = objUser.profile.createdAt;
  platformObj.location = objUser.profile.location;

  if (objUser.profile.status) {
    platformObj.status.message = objUser.profile.status.message;
    platformObj.status.emojiHTML = objUser.profile.status.emojiHTML;
  } else {
    platformObj.status.message = null;
    platformObj.status.emojiHTML = null;
  }

  /** platform.organizations.(?) */
  objUser.profile.organizations.edges.forEach(_org => {
    orgObj.avatarUrl = _org.node.avatarUrl;
    orgObj.name = _org.node.name;
    orgObj.orgUrl = _org.node.url;

    /** platform.organizations.member.(?) */
    _org.node.membersWithRole.nodes.forEach(_member => {
      memberObj.avatarUrl = _member.avatarUrl;
      memberObj.name = _member.name;
      memberObj.webUrl = _member.url;

      orgObj.members.push(memberObj);
    });
    platformObj.organizations.push(orgObj);
  });

  const getContributionsByRepositories = (repositories) => {
    var contributions = []
    console.log(repositories)
    for (const [r, repo] of repositories.entries()) {
      //console.log(repo)
      //var contrib = Object.assign({},contribObj)
      var contrib = contribObj
      contrib.repoUrl = repo.repository.url;
      contrib.nameWithOwner = repo.repository.nameWithOwner;


      for (const [c, edge] of repo.repository.defaultBranchRef.target.history.edges.entries()) {
        var commit = edge.node
        contrib.time = commit.committedDate.split("T")[1]
        //console.log(contrib)
        contributions.push(contrib)
      }
      return contributions

    }
  }

  const ys = getContributionsByRepositories(year.commitContributionsByRepository)

  const getContributionsByDate = (date, year) => {
    var contributions = Object.assign({},dayObj.contributions)
    contributions.commits = ys

    return contributions
}

  //> Years
  for (let c = 1; c < Object.values(objUser.calendar).length; c++) {
    const year = objUser.calendar[`c${c}`];
      

    for (const [w, week] of year.contributionCalendar.weeks.entries()) {
      //console.log('%d: %s', w, week);
      for (const [d, day] of week.contributionDays.entries()) {
        //console.log('%d: %s', d, day);
        dayObj.date = day.date;
        dayObj.total = day.contributionCount;
        dayObj.week = w;
        dayObj.weekday = d;

        yearObj.calendar[day.date] = dayObj;

        dayObj.contributions = getContributionsByDate(day.date, year)
        //console.log(dayObj.contributions)
        
      }
    }


  }

  

  //getContributionsByDate(year.issueContributionsByRepository.entries())



  
  /*
  for (let c = 1; c < Object.values(objUser.calendar).length; c++) {
    const element = objUser.calendar[`c${c}`];

    for (let w = 0; w < element.contributionCalendar.weeks.length; w++) {
      const week = element.contributionCalendar.weeks[i]
      for (let d = 0; d < element.contributionCalendar.weeks.length; i++) {

      }


      const week = element.contributionCalendar.weeks[i].forEach(_day => {
        year.calendar[`${}`]
      });

      console.log(week)
    }
    
  }
  */

  return platformObj;
}

console.log(platformObj);
